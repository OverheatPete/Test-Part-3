print("Quarto Version 1.0 by Eenfeeneetee")
print("Players place pieces given by the opponent. Each piece has either O or X for each of their four traits. Whoever lines up 4 pieces with at least one same trait wins.")
print("https://en.wikipedia.org/wiki/Quarto_(board_game)")
tile = "OOOO"
pos = ""
player = "⬛"
win = 0
unusedTile = ["OOOX", "OOXO", "OOXX", "OXOO", "OXOX", "OXXO", "OXXX", "XOOO", "XOOX", "XOXO", "XOXX", "XXOO", "XXOX", "XXXO", "XXXX"]
unusedPos = ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"]
rowA = "│         │         │         │         │"
rowB = "│         │         │         │         │"
rowC = "│         │         │         │         │"
rowD = "│         │         │         │         │"
def grid():
  for i in range(0, 3):
    print()
  print("┌─────1─────2─────3─────4")
  print(rowA[:6]+rowA[10:16]+rowA[20:26]+rowA[30:36]+"│")
  print("│"+rowA[5:11]+rowA[15:21]+rowA[25:31]+rowA[35:])
  print("A─────┼─────┼─────┼─────┤")
  print(rowB[:6]+rowB[10:16]+rowB[20:26]+rowB[30:36]+"│")
  print("│"+rowB[5:11]+rowB[15:21]+rowB[25:31]+rowB[35:])
  print("B─────┼─────┼─────┼─────┤")
  print(rowC[:6]+rowC[10:16]+rowC[20:26]+rowC[30:36]+"│")
  print("│"+rowC[5:11]+rowC[15:21]+rowC[25:31]+rowC[35:])
  print("C─────┼─────┼─────┼─────┤")
  print(rowD[:6]+rowD[10:16]+rowD[20:26]+rowD[30:36]+"│")
  print("│"+rowD[5:11]+rowD[15:21]+rowD[25:31]+rowD[35:])
  print("D─────┴─────┴─────┴─────┘")

for i in range(0, 16):
  grid()
  tileList = ""
  for j in range (0, len(unusedTile)):
    tileList = tileList + unusedTile[j] + " "
  #Choose tile for your opponent
  if len(unusedPos) < 16:
    print(tileList)
    while True:
      print("                                      Q R")
      tile = input("Player "+player+" : Choose piece for opponent. S T (Ex: OXOX): ")
      tile = tile.upper()
      if tile in unusedTile:
        unusedTile.remove(tile)
        break
      else:
        print("Illegal Piece!")
    grid()
  if player == "⬛":
    player = "⬜"
  else:
    player = "⬛"
  #Choose Location
  while True:
    print("                       "+tile[0]+" "+tile[1])
    pos = input("Player "+player+" : Place piece "+tile[2]+" "+tile[3]+" (Ex: B2): ")
    pos = pos.upper()
    if pos in unusedPos:
      unusedPos.remove(pos)
      break
    else:
      print("Illegal position!")
  #Place Piece on Board
  m = 10*int(pos[1])-8
  if pos[0] == "A":
    rowA = rowA[:m]+tile[0]+" "+tile[1]+" "+tile[2]+" "+tile[3]+rowA[m+7:]
    for j in range(0, 4):
      nn = chr(9359+ord(tile[j]))
      if tile[j] == rowA[2*j+2] == rowA[2*j+12] == rowA[2*j+22] == rowA[2*j+32]:
        rowA = rowA[:2*j+2]+nn+rowA[2*j+3:2*j+12]+nn+rowA[2*j+13:2*j+22]+nn+rowA[2*j+23:2*j+32]+nn+rowA[2*j+33:]
        win = 1
  elif pos[0] == "B":
    rowB = rowB[:m]+tile[0]+" "+tile[1]+" "+tile[2]+" "+tile[3]+rowB[m+7:]
    for j in range(0, 4):
      nn = chr(9333+ord(tile[j]))
      if tile[j] == rowB[2*j+2] == rowB[2*j+12] == rowB[2*j+22] == rowA[2*j+32]:
        rowB = rowB[:2*j+2]+nn+rowB[2*j+3:2*j+12]+nn+rowB[2*j+13:2*j+22]+nn+rowB[2*j+23:2*j+32]+nn+rowB[2*j+33:]
        win = 1
  elif pos[0] == "C":
    rowC = rowC[:m]+tile[0]+" "+tile[1]+" "+tile[2]+" "+tile[3]+rowC[m+7:]
    for j in range(0, 4):
      nn = chr(9333+ord(tile[j]))
      if tile[j] == rowC[2*j+2] == rowC[2*j+12] == rowC[2*j+22] == rowC[2*j+32]:
        rowC = rowA[:2*j+2]+nn+rowC[2*j+3:2*j+12]+nn+rowC[2*j+13:2*j+22]+nn+rowC[2*j+23:2*j+32]+nn+rowC[2*j+33:]
        win = 1
  elif pos[0] == "D":
    rowD = rowD[:m]+tile[0]+" "+tile[1]+" "+tile[2]+" "+tile[3]+rowD[m+7:]
    for j in range(0, 4):
      nn = chr(9333+ord(tile[j]))
      if tile[j] == rowD[2*j+2] == rowD[2*j+12] == rowD[2*j+22] == rowD[2*j+32]:
        rowD = rowD[:2*j+2]+nn+rowD[2*j+3:2*j+12]+nn+rowD[2*j+13:2*j+22]+nn+rowD[2*j+23:2*j+32]+nn+rowD[2*j+33:]
        win = 1
  #Vertical and Diagonal Wincons
  for j in range(0, 4):
    if tile[j] == rowA[2*j+m] == rowB[2*j+m] == rowC[2*j+m] == rowD[2*j+m]:
      rowA = rowA[:2*j+m]+chr(9333+ord(tile[j]))+rowA[2*j+m+1:]
      rowB = rowB[:2*j+m]+chr(9333+ord(tile[j]))+rowB[2*j+m+1:]
      rowC = rowC[:2*j+m]+chr(9333+ord(tile[j]))+rowC[2*j+m+1:]
      rowD = rowD[:2*j+m]+chr(9333+ord(tile[j]))+rowD[2*j+m+1:]
      win = 1
    elif tile[j] == rowA[2*j+2] == rowB[2*j+12] == rowC[2*j+22] == rowD[2*j+32]:
      rowA = rowA[:2*j+2]+chr(9333+ord(tile[j]))+rowA[2*j+3:]
      rowB = rowB[:2*j+12]+chr(9333+ord(tile[j]))+rowB[2*j+13:]
      rowC = rowC[:2*j+22]+chr(9333+ord(tile[j]))+rowC[2*j+23:]
      rowD = rowD[:2*j+32]+chr(9333+ord(tile[j]))+rowD[2*j+33:]
      win = 1
    elif tile[j] == rowA[2*j+32] == rowB[2*j+22] == rowC[2*j+12] == rowD[2*j+2]:
      rowA = rowA[:2*j+32]+chr(9333+ord(tile[j]))+rowA[2*j+33:]
      rowB = rowB[:2*j+22]+chr(9333+ord(tile[j]))+rowB[2*j+23:]
      rowC = rowC[:2*j+12]+chr(9333+ord(tile[j]))+rowC[2*j+13:]
      rowD = rowD[:2*j+2]+chr(9333+ord(tile[j]))+rowD[2*j+3:]
      win = 1
  if win == 1:
    break
grid()
if win == 1:
  print("Player "+player+" wins.")
else:
  print("It's a tie.")